<?php

namespace Controllers;

use MVC\Router;
use Model\Admin;


class LoginController {

    public static function login(Router $router) {
        $errores = [];

        if($_SERVER['REQUEST_METHOD'] === 'POST') {

            $auth = new Admin($_POST);

            $errores = $auth->validar();

            if( empty($errores) ){
                //Verificar si el usuario existe
                $resultado = $auth->existeUsuario();

                if(!$resultado) {
                    //verificar si el usuario existe o no (mensaje de error)
                    $errores = Admin::getErrores();
                } else {
                    //verificar el password
                    $autenticado = $auth->comprobarPassword($resultado);


                    
                    if($autenticado) {
                        //Autenticar al usuario
                        $auth->autenticar();

                    } else {
                        //password incorrecto mensaje de errror
                        $errores = Admin::getErrores();
                    }
                    

                }

                
            }

        }


        $router->render('auth/login', [
            'errores' => $errores
        ]);
    }

    public static function logout( Router $router ) {
        session_start();

        $_SESSION = [];
        session_destroy();
        
        header('Location: /');
        exit;

    }


}