<?php 
    use App\Propiedad;
    
    if($_SERVER['SCRIPT_NAME'] === '/anuncios.php') {
        $propiedades = Propiedad::all();
    } else {
        $propiedades = Propiedad::get(3);
    }

?>


<div class="contenedor-anuncios">
    <?php foreach($propiedades as $propiedad){ ?>
    <div class="anuncios">
        
        <img loading="lazy" src="/imagenes/<?php echo $propiedad->imagen; ?>" alt="anuncio1"> 
        
        <div class="contenido-anuncios">
            <h3><?php echo $propiedad->titulo; ?></h3>
            <p><?php echo $propiedad->descripcion; ?></p>
            <p class="precio">$ <?php echo $propiedad->precio; ?></p>
            <al class="iconos-caracteristicas">
                <li>
                    <img class="iconos" loading="lazy" src="/build/img/icono_wc.svg" alt="icono wc">
                    <p><?php echo $propiedad->wc; ?></p>
                </li>
                <li>
                    <img class="iconos" loading="lazy" src="/build/img/icono_estacionamiento.svg" alt="icono estacionamiento">
                    <p><?php echo $propiedad->estacionamiento; ?></p>
                </li>
                <li>
                    <img class="iconos" loading="lazy" src="/build/img/icono_dormitorio.svg" alt="icono habitaciones">
                    <p><?php echo $propiedad->habitaciones; ?></p>
                </li>
            </al>

            <a href="/anuncio.php?id=<?php echo $propiedad->id; ?>" class="boton boton-amarillo-block">
                Ver Propiedad
            </a>
        </div><!--contenido anuncio-->
    </div><!--anuncio-->
    <?php } ?>
</div><!--.contenedor-anuncios-->

<?php 
    //cerrar la conexion
    
?>